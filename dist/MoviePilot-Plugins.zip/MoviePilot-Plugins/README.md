# TgtoDrive STRM 同步插件（MoviePilot）

MoviePilot 整理入库（`TransferComplete` 事件）后，自动调用 **TgtoDrive 官方 OpenAPI**
触发生成网盘 STRM，等待生成完成后刷新 **Emby** / **Jellyfin** / **飞牛影视** 媒体库，并发送通知。

## 工作流程

```
MoviePilot 整理入库
      │  (EventType.TransferComplete)
      ▼
[防抖合并 N 秒]
      ▼
POST {TgtoDrive}/api/strm-sync/run   { "source": "123云盘" }
      │  (Bearer OpenAPI Token)
      ▼
等待 X 秒（TgtoDrive 的 STRM 同步为后台异步任务）
      ▼
刷新媒体库（按已配置的服务器逐个刷新）
  ├─ Emby（复用 MoviePilot 已配置的 Emby，或插件内单独配置）
  ├─ Jellyfin（同上，仅整库刷新）
  └─ 飞牛影视（启用时，全库或指定媒体库）
      ▼
发送通知 + 记录执行历史
```

> ⚠️ TgtoDrive 的 `/api/strm-sync/run` 只返回「任务已开始」，官方 OpenAPI 中**没有提供
> STRM 同步的完成回调 / 进度查询接口**。因此本插件用「触发后等待 N 秒」来估算生成时间，
> 请根据网盘规模把「触发后等待秒数」调到合适值（默认 60 秒）。

## 前置：在 TgtoDrive 里创建 OpenAPI Token

1. 打开 TgtoDrive 管理台 `http://<NAS_IP>:12366` 并登录。
2. 进入「**实用工具 → OpenAPI**」。
3. 点击创建访问令牌，**完整令牌只在创建时显示一次**，复制保存（服务端只存 SHA-256 摘要）。
4. 令牌具有后台管理员权限，请只用于可信脚本；最多同时保存 20 个，撤销后立即失效。

## 前置（可选）：在 MoviePilot 中配置飞牛影视

插件**直接依赖 MoviePilot 内置的飞牛影视模块**（`app.modules.trimemedia`），
不再自己实现接口与签名。使用前请在 MoviePilot「**设定 → 媒体服务器**」中添加飞牛影视
（填飞牛地址、管理员账号等），插件会自动复用这份配置，无需在插件里重复填写地址与密钥。

> ⚠️ 必须使用**管理员账号**：飞牛只有管理员才能触发媒体库刷新，非管理员会直接失败。

## 安装

### 方式一：作为自定义插件市场（推荐）

1. MoviePilot →「设定 → 插件市场 → 添加市场」，填入本仓库地址：

   ```
   https://github.com/KingNuoNuo/MoviePilot-Plugins
   ```

2. 保存后，在市场里搜索「**TgtoDrive STRM 同步**」并安装、启用。

仓库结构：

```
MoviePilot-Plugins/
├── package.json                 # 插件清单（市场识别）
└── plugins/
    └── tgtodrivesync/
        └── __init__.py          # 插件主体（类名 TgtoDriveSync）
```

### 方式二：本地直接放置

把 `plugins/tgtodrivesync` 整个目录拷贝到 MoviePilot 的插件目录（容器内通常为
`/app/app/plugins/`，以你的实际部署为准），重启 MoviePilot 容器即可在插件列表看到。

## 配置项

| 配置 | 说明 | 默认 |
| --- | --- | --- |
| 启用插件 | 总开关 | 关 |
| 发送通知 | 流程结果是否发通知 | 开 |
| TgtoDrive 地址 | 例如 `http://10.0.0.4:12366` | 空 |
| TgtoDrive OpenAPI Token | 上一步创建的令牌 | 空 |
| STRM 同步来源 | `123云盘` / `115网盘` / `光鸭云盘` 及各自音乐/分享 | `123云盘` |
| Emby 刷新方式 | 刷新全部媒体库 / 按入库条目刷新 | 全部媒体库 |
| 触发后等待秒数 | 等待 STRM 生成的时间 | 60 |
| 防抖秒数 | 合并短时间内的多次入库 | 30 |
| Emby 地址 / API Key | 可选。留空则复用 MoviePilot 已配置的媒体服务器 | 空 |
| Jellyfin 地址 / API Key | 可选。留空则复用 MoviePilot 已配置的媒体服务器 | 空 |
| 启用飞牛影视刷新 | 是否在 STRM 生成后刷新飞牛影视 | 关 |
| 飞牛扫描范围 | 刷新全部媒体库 / 仅刷新指定媒体库 | 全部媒体库 |
| 指定媒体库名称 | 扫描范围选「仅指定」时填写，如 `电影库` | 空 |
| 指定飞牛媒体服务器名称 | 可选。配置了多个飞牛时指定刷新哪一个，留空刷新全部 | 空 |

## 手动触发

- **插件 API**（需带 MoviePilot 的 `API_TOKEN`）：
  - `GET /api/v1/plugin/TgtoDriveSync/trigger?apikey=xxx` — 立即触发同步并刷新
  - `GET /api/v1/plugin/TgtoDriveSync/test?apikey=xxx` — 测试 TgtoDrive 连接
- **远程命令**：`/tgtodrive_sync`（在支持命令的渠道中发送）

## 直接验证 TgtoDrive 接口

```bash
# 触发 123 云盘 STRM 同步
curl -X POST "http://10.0.0.4:12366/api/strm-sync/run" \
  -H "Authorization: Bearer <OPENAPI_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"source":"123云盘"}'

# 期望响应： {"success": true, "message": "..."}
```

## 打包产物

`dist/` 目录下提供可直接使用的压缩包：

| 文件 | 说明 |
| --- | --- |
| `MoviePilot-Plugins.zip` | 完整插件仓库结构（`package.json` + `plugins/tgtodrivesync/`），解压即可推 Git 或当市场源 |
| `tgtodrivesync.zip` | 仅插件目录，解压后把 `tgtodrivesync/` 放进 MoviePilot 插件目录 |

## 已知边界

- TgtoDrive 无 STRM 完成回调，刷新的时机靠「等待秒数」估算；若同步较慢可调大该值。
- `source` 取值取自 TgtoDrive 前端枚举，若其版本升级后新增来源，请在
  `__init__.py` 顶部的 `STRM_SOURCES` 中同步补充。
- 「按入库条目刷新」依赖 MoviePilot 提供的 `RefreshMediaItem`；若匹配不到媒体库会退化为无操作，
  建议优先使用「刷新全部媒体库」。
- **媒体的刷新只在「已配置」时执行**：Emby / Jellyfin 需在 MoviePilot 里配置或插件内填地址+Key，
  飞牛需开启开关并配好媒体服务器，否则该目标不会出现在结果里。
- **Jellyfin 只支持整库刷新**：MoviePilot 的 Jellyfin 模块未提供按条目刷新接口，「刷新方式」对它不生效。
- **飞牛刷新依赖 MoviePilot 版本**：插件通过 `MediaServerHelper` 拿飞牛实例（v2 在 `app.helper`、
  v3 在 `app.application`，已做双路径兼容），并按 `ServiceInfo.type == trimemedia` 识别。
  若你的 MoviePilot 未内置 `app.modules.trimemedia`，飞牛刷新会返回明确错误提示，其它目标不受影响。
- 飞牛刷新需**管理员账号**，且需在 MoviePilot 中已配置并启用飞牛影视媒体服务器。
