# 猫眼榜单订阅（MaoyanRank）

> [← 返回插件一览](../../README.md#插件一览) · 版本 v1.0.0 · 目录 `plugins.v3/maoyanrank`

按配置的榜单类型、平台和排名数量获取猫眼数据，识别媒体后添加订阅；
同时把抓取结果落成**榜单快照**，通过对外接口提供给 App、脚本与宿主推荐页。

## 来源

本插件 **Fork 自 [jxxghp/moviepilot-plugins](https://github.com/jxxghp/moviepilot-plugins)**
中的 `plugins.v3/maoyanrank/`（上游原插件「猫眼榜单订阅」，原作者
[逗猫 @baozaodetudou](https://github.com/baozaodetudou)）。

- 上游版本：**v4.1.4**；本仓库基于该版本改造为**独立发行版**，版本号自本仓库从
  **v1.0.0** 重新计数（不沿用上游编号），作者与主页署名均为本仓库（`KingNuoNuo`）
- 上游能力：抓取猫眼榜单 → 识别媒体 → 添加订阅
- 本仓库新增：榜单对外接口（`/rank`、`/rank-list`、`/refresh`）、榜单快照
  （含名次 / 票房 / 热度 / 媒体身份）与宿主推荐页数据源，见下文
- 图标已迁入本仓库（`icons/maoyan.png`），不再引用上游仓库资源

## 上游同步

上游改动通过**三方合并**自动跟进（工作流 `sync-maoyanrank.yml`，基线存于 `.upstream/maoyanrank/`）：
上游一有更新就开 PR，无冲突时自动递增 patch 版本号并重建打包产物。详见仓库根 README 的「自动同步上游」。

## 安装

MoviePilot →「设定 → 插件市场 → 添加市场」，填入
`https://github.com/KingNuoNuo/MoviePilot-Plugins`，保存后搜索「**猫眼榜单订阅**」安装并启用。

本地部署也可把 `plugins.v3/maoyanrank` 整个目录拷贝到 MoviePilot 的插件目录
（容器内通常为 `/app/app/plugins/`，以你的实际部署为准），重启容器即可。

## 对外接口

注册在宿主 `/api/v1/plugin/MaoyanRank` 前缀下，默认使用宿主的 **API 令牌**认证
（`X-API-KEY` 头或 `?apikey=` 查询参数），也可用网页登录态调用。

| 接口 | 返回 | 说明 |
| --- | --- | --- |
| `GET /rank` | `Response[MaoyanRankSnapshot]` | 榜单快照，含名次、类型、平台、票房/热度、媒体身份与海报 |
| `GET /rank-list` | `Response[List[MediaInfo]]` | 推荐页 / 浏览页数据源，声明 `page` 参数 |
| `GET` `POST /refresh` | `MaoyanRefreshResult` | 立即触发一次抓取与订阅 |

`/rank` 支持三个可选参数：

- `board_type`：`movie`（电影票房）、`web-movie`（网络电影）、`web-heat`（电视剧热度）、
  `web-tv`（网络剧热度）、`zongyi`（综艺热度）
- `board`：榜单名关键字，如 `腾讯视频`
- `limit`：每个榜单最多返回的条目数，用于限制响应体大小

```bash
curl "http://<MP>:3000/api/v1/plugin/MaoyanRank/rank?apikey=<API_TOKEN>&limit=5"
curl "http://<MP>:3000/api/v1/plugin/MaoyanRank/rank?apikey=<API_TOKEN>&board_type=web-heat"
curl -X POST "http://<MP>:3000/api/v1/plugin/MaoyanRank/refresh?apikey=<API_TOKEN>"
```

响应为宿主统一三段式 `{ success, message, data }`，`data.boards[].items[]` 即榜单条目。
**未识别到媒体的条目仍会返回**（身份字段为空），便于调用方先渲染榜单。

## 接入宿主推荐页（可选）

配置中打开「接入推荐页数据源」后，插件通过 `ChainEventType.RecommendSource`
把已配置的榜单注册到宿主推荐页：电影票房进「电影」分类，
电视剧 / 网络剧 / 综艺热度进「电视剧」分类。注册是**叠加**到事件数据，
不会影响其它插件的数据源。

## 快照与兜底

- 每次刷新把榜单落成插件数据 `snapshot`（含逐条回填的媒体来源、ID、海报、简介、年份）。
- **抓取全失败时保留上一次快照**，避免异常时段接口返回空数据。
- 升级后尚未跑过刷新时，`/rank` 回退到订阅流水并在 `message` 中注明，保证接口始终可用。
- `/rank-list` 会过滤掉没有媒体身份的条目，因为它们无法被宿主识别为媒体。

## 异常处理

- 上映信息为空或为未知文案时，使用未知年份继续识别；明确上映日期、已上映天数和首日文案按对应规则解析。
- 电视剧、网剧和综艺使用官网当前热度接口，按北京时间查询当天榜单，保留各平台筛选。每轮刷新复用一个官网浏览器会话，由页面脚本处理请求校验。
- 浏览器启动或页面加载失败时，继续尝试无 Cookie 请求未处理榜单；热度接口需要页面校验，此时可能仍返回 403。失败来源会明确记录，不影响其他来源继续处理。
- 一个来源请求失败、返回非 JSON 或响应结构异常时，记录来源地址并继续其他榜单。
- 榜单内的无效条目、单条媒体识别或订阅异常只影响该条目，日志标明来源排名或媒体标题。
- 跳过坏条目后不补取配置排名范围之外的内容；保留跨平台剧集去重，成功订阅的条目仍保存历史。

出现部分失败后，可从日志中的来源地址、排名和媒体标题定位问题；“刷新完成”表示本轮遍历结束，不代表所有来源都成功。
