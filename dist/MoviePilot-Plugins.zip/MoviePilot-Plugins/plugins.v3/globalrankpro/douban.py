"""豆瓣检索：给榜单条目补海报与评分。

为什么放在插件侧
----------------
猫眼榜单（热度榜 / 网络剧榜 / 综艺榜 / 票房榜）和 Netflix 榜单本身都不带评分。
要让 App 显示评分，只能额外去豆瓣查一次；如果让 App 自己去查，海报墙一屏十几条
就是十几次跨境 HTTPS 请求，既慢又容易被豆瓣限流（实测连打几次后直接返回空）。

宿主机网络更接近豆瓣，且结果可以持久缓存、全端共享，所以评分统一在插件里补好，
随 ``/rank`` 一次性吐给 App（字段 ``vote_average``）。

豆瓣接口的坑（2026-10 实测）
---------------------------
- **旧检索接口 ``movie.douban.com/j/subject_suggest`` 已失效**：无论查什么都返回
  空数组 ``[]``（HTTP 200），看起来像「豆瓣没这部片」，其实是接口不再给数据。
  ``movie.douban.com/j/search_subjects`` 还把 ``tag`` 当分类标签而不是关键词。
- 现在用移动站的 **``m.douban.com/rexxar/api/v2/search``**：一次请求直接带
  ``rating.value``，中文名 / 年份 / 封图都有 —— 不用再补第二次 ``subject_abstract``，
  **一条 = 1 个请求**（旧方案是 2 个），限流风险和对豆瓣的压力都减半。
- 必须带 ``Referer: https://m.douban.com/``；请求过密会被拦（表现为返回空或
  「检测到异常请求」文案）。这里做了全局节流与熔断：连续失败即整体收手一段时间，
  已拿到的照常落库。
"""
from __future__ import annotations

import datetime
import random
import re
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from app.sdk.config import settings
from app.sdk.logging import logger
from app.sdk.network import RequestUtils

_SEARCH_URL = "https://m.douban.com/rexxar/api/v2/search"
_REFERER = "https://m.douban.com/"

# 请求间隔：连打会被拦（表现为返回空 / 抛异常），0.35s 实测稳定
_REQUEST_INTERVAL = 0.35
# 熔断冷却：一旦某次请求抛异常、或连续多次拿到空结果，这段时间内不再打豆瓣
_BLOCK_COOLDOWN = 600.0
# 连续多少次「查了但一条候选都没有」就认定被限流（正常检索几乎不会连空）
_EMPTY_STREAK_LIMIT = 12

# 评分缓存有效期：豆瓣评分变动很慢，30 天足够；还没开分的条目（新片）3 天后再试
RATING_TTL = 30 * 86400
RATING_TTL_MISS = 3 * 86400

# 检索策略版本：换接口或换匹配规则时 +1，老缓存自动判过期重查。
# v1 = movie.douban.com/j/subject_suggest（该接口已失效，之前存下来的空结果全是假的）
# v2 = m.douban.com/rexxar/api/v2/search（一次请求带 rating.value）
# v3 = 修好「rexxar 返回 None」的排障（v2 存下来的空值多半是拿不到响应，不是真没分）
RATING_VER = 3

_UAS = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
)

_last_request_at = 0.0
_blocked_until = 0.0
_empty_streak = 0
# 最近一次原始响应（只给 /rating?debug=1 排障用，正常路径不读）
last_raw: Any = None


def is_blocked() -> bool:
    """本轮是否已被豆瓣限流（熔断中）。"""
    return time.monotonic() < _blocked_until


def _trip(reason: str) -> None:
    global _blocked_until, _empty_streak
    _blocked_until = time.monotonic() + _BLOCK_COOLDOWN
    # 冷却结束从零计：不清的话冷却一过、第一条查不到就会立刻再次熔断
    _empty_streak = 0
    logger.warning(
        f"豆瓣请求失败，{int(_BLOCK_COOLDOWN / 60)} 分钟内不再尝试：{reason}")


def _get_json(url: str, params: Dict[str, Any]) -> Any:
    """带节流与熔断的 GET，失败一律返回 None（调用方按「没查到」处理）。

    走 ``RequestUtils.get`` 而不是 ``get_json``：后者在「非 200 / 非 JSON」时一律返回
    None，线上排障时分不清「豆瓣给的是空列表」和「被拦/重定向到验证页」。
    这里把状态码与前 300 字留在 [last_raw] 里（只给 debug=1 看）。
    """
    global _last_request_at, last_raw
    if is_blocked():
        return None
    gap = time.monotonic() - _last_request_at
    if gap < _REQUEST_INTERVAL:
        time.sleep(_REQUEST_INTERVAL - gap)
    _last_request_at = time.monotonic()
    try:
        client = RequestUtils(
            headers={"User-Agent": random.choice(_UAS)},
            proxies=getattr(settings, "PROXY", None),
            referer=_REFERER,
        )
        if hasattr(client, "get"):
            res = client.get(url, params=params)
            status = getattr(res, "status_code", None)
            text = getattr(res, "text", "") or ""
            last_raw = f"HTTP {status} | {text[:300]}"
            if status and status != 200:
                return None
            try:
                return res.json()
            except Exception:
                return None
        data = client.get_json(url, params=params)
        last_raw = data if data is not None else "get_json 返回 None"
        return data
    except Exception as err:
        last_raw = f"EXC: {err}"
        _trip(str(err))
        return None


def _rate_text(value: Any) -> str:
    """把 rexxar 的 ``rating.value``（数字，0 表示未开分）收敛成 "8.4" / "9.0"。"""
    try:
        rate = float(value or 0)
    except (TypeError, ValueError):
        return ""
    if rate <= 0:
        return ""
    return f"{rate:.1f}"


def _search(keyword: str) -> List[dict]:
    """搜一次豆瓣，返回规范化候选（title / year / rate / kind / img / id）。

    一次请求就带评分（``rating.value``），不再需要第二次 ``subject_abstract``。
    """
    global _empty_streak
    data = _get_json(_SEARCH_URL, {"q": keyword, "start": 0, "count": 10})
    items: Any = None
    if isinstance(data, dict):
        subjects = data.get("subjects")
        if isinstance(subjects, dict):
            items = subjects.get("items")
    if not isinstance(items, list):
        items = []
    out: List[dict] = []
    for item in items:
        target = item.get("target") if isinstance(item, dict) else None
        if not isinstance(target, dict):
            continue
        uri = str(target.get("uri") or "")
        rating = target.get("rating")
        if not isinstance(rating, dict):
            rating = {}
        out.append({
            "id": str(target.get("id") or ""),
            "title": str(target.get("title") or "").strip(),
            "year": str(target.get("year") or "").strip(),
            "img": str(target.get("cover_url") or ""),
            # 类型只能从 uri 认（`douban://douban.com/tv/<id>`）；同名电影/剧集要靠它区分
            "kind": "tv" if "/tv/" in uri else ("movie" if "/movie/" in uri else ""),
            "rate": _rate_text(rating.get("value")),
        })
    # 连续拿到空结果 = 多半被限流（正常检索不会一直空），累计到阈值就熔断
    if out:
        _empty_streak = 0
    else:
        _empty_streak += 1
        if _empty_streak >= _EMPTY_STREAK_LIMIT:
            _trip(f"连续 {_empty_streak} 次检索为空")
    return out


def _pick(pool: Sequence[dict], title: str, prefer_tv: Optional[bool]) -> dict:
    """从候选里挑一条：同名优先，再按电影/剧集偏好排序。"""
    same = [c for c in pool if str(c.get("title") or "").strip() == title]
    if same:
        pool = same
    if prefer_tv is True:
        pool = sorted(pool, key=lambda c: 0 if c.get("kind") == "tv" else 1)
    elif prefer_tv is False:
        pool = sorted(pool, key=lambda c: 0 if c.get("kind") == "movie" else 1)
    for candidate in pool:
        if str(candidate.get("id") or ""):
            return candidate
    return {}


def _poster_of(candidate: dict) -> str:
    img = candidate.get("img")
    if isinstance(img, str) and img.startswith("http"):
        # rexxar 给的是大图（cover_url 已带签名），直接用
        return img
    return ""


def _title_of(candidate: dict) -> str:
    return str(candidate.get("title") or "").strip()


def _year_of(candidate: dict) -> str:
    return str(candidate.get("year") or "").strip()


def lookup(
    title: str,
    *,
    keywords: Optional[Iterable[str]] = None,
    year: str = "",
    prefer_tv: Optional[bool] = None,
    need_poster: bool = True,
    need_rating: bool = True,
) -> Dict[str, Any]:
    """
    按标题在豆瓣找词条，取海报与评分。

    :param title: 榜单原始标题（用于同名判定与日志）
    :param keywords: 检索词优先级列表；Netflix 这类英文片名传 `[中文名, 英文名]` 命中率最高
    :param year: 年份，用于「截短检索」时的严格校验（宁可空缺也不张冠李戴）
    :param prefer_tv: True 表示剧集、False 表示电影，同名候选按它排序
    :param need_poster: 需要海报时才解析封图
    :param need_rating: 需要评分（评分随搜索结果一起回来，不再额外请求）

    返回 ``{"id", "rate", "poster", "title"}``，查不到的项为空串。
    """
    result = {"id": "", "rate": "", "poster": "", "title": ""}
    if not title or is_blocked():
        return result

    words = [w for w in re.split(r"[\s:：\-—–·,，.。!！?？/]+", title) if w]
    queries: List[str] = []
    for keyword in (keywords or ()):
        keyword = str(keyword or "").strip()
        if keyword and keyword not in queries:
            queries.append(keyword)
    if title not in queries:
        queries.append(title)

    def settle(candidate: dict) -> Dict[str, Any]:
        result["id"] = str(candidate.get("id") or "")
        result["title"] = _title_of(candidate)
        if need_poster:
            result["poster"] = _poster_of(candidate)
        if need_rating:
            result["rate"] = str(candidate.get("rate") or "")
        return result

    # ① 整串检索：命中的都是原文匹配，直接采纳（不校验年份，同名已经足够严格）
    for query in queries:
        pool = _search(query)
        if not pool:
            continue
        candidate = _pick(pool, query, prefer_tv)
        if candidate:
            return settle(candidate)

    # ② 截短检索：只对带年份的条目前瞻降级，且年份必须完全一致。
    #    长英文片名在豆瓣常常整串搜不到（实测「Chiikawa the Movie: The Secret of
    #    Mermaid Island」返回空，但「Chiikawa」能命中《吉伊卡哇：人鱼之岛的秘密》），
    #    所以按词逐步减少检索词再试；拿不到年份的条目不参与降级，宁可不补也不认错。
    year = str(year or "").strip()
    if not re.fullmatch(r"(?:19|20)\d{2}", year):
        return result
    for size in (1, 2, 3):
        if size >= len(words):
            continue
        keyword = " ".join(words[:size])
        if len(keyword) < 3:
            continue
        matched = [c for c in _search(keyword) if _year_of(c) == year]
        candidate = _pick(matched, keyword, prefer_tv)
        if candidate:
            logger.info(
                f"豆瓣整串无结果，改用关键词「{keyword}」命中 {_title_of(candidate)}")
            return settle(candidate)
    return result


def probe() -> List[str]:
    """连通性探针（``/rating?debug=2``）：把几种取数方式对几个豆瓣地址各打一次。

    线上症状是「rexxar 拿不到任何东西，而 old suggest 接口至少还能返回 JSON 空数组」，
    需要区分「域名不通 / 方法用错 / 被拦」这三件事，所以这里两种方法都试。
    结果只用于排障，不写缓存、不参与限流判断。
    """
    targets = (
        ("movie首页", "https://movie.douban.com/"),
        ("m首页", "https://m.douban.com/"),
        ("rexxar", f"{_SEARCH_URL}?q=test&start=0&count=1"),
    )
    out: List[str] = []
    for name, url in targets:
        for method in ("get", "get_json"):
            try:
                client = RequestUtils(
                    headers={"User-Agent": random.choice(_UAS)},
                    proxies=getattr(settings, "PROXY", None),
                    referer=_REFERER,
                )
                fn = getattr(client, method, None)
                if fn is None:
                    out.append(f"{name}.{method}=无此方法")
                    continue
                res = fn(url)
                if res is None:
                    out.append(f"{name}.{method}=None")
                elif method == "get":
                    status = getattr(res, "status_code", None)
                    text = getattr(res, "text", "")
                    out.append(f"{name}.{method}=HTTP{status}/len{len(text or '')}")
                else:
                    out.append(f"{name}.{method}=ok/{type(res).__name__}")
            except Exception as err:
                out.append(f"{name}.{method}=EXC:{type(err).__name__}")
    return out


def cache_key(title: str, year: str = "", media_type: str = "") -> str:
    """搜索评分缓存的键：标题 + 年份 + 类型。

    同一部片重拍要区分开（「射雕英雄传」有 1983 与 2017 两版），所以年份进键；
    类型只影响「剧集/电影候选排序」，也一并进键，避免剧/影互相覆盖。
    """
    return "|".join((
        str(title or "").strip().lower(),
        str(year or "").strip(),
        str(media_type or "").strip().lower(),
    ))


def is_fresh(entry: Dict[str, Any], now_ts: float) -> bool:
    """持久缓存里的评分是否还能用（命中 30 天 / 未开分 3 天）。

    检索策略版本不匹配的一律判过期：换接口后，旧版本存下来的「查不到」是假结论。
    """
    if not isinstance(entry, dict) or "rating_ts" not in entry:
        return False
    if entry.get("rating_ver") != RATING_VER:
        return False
    try:
        ts = float(entry.get("rating_ts") or 0)
    except (TypeError, ValueError):
        return False
    ttl = RATING_TTL if str(entry.get("vote_average") or "0") not in ("", "0", "0.0") \
        else RATING_TTL_MISS
    return now_ts - ts < ttl


def fill_ratings(
    pairs: Iterable[Tuple[str, Dict[str, Any]]],
    *,
    budget: int,
    now: Optional[datetime.datetime] = None,
) -> int:
    """
    给一批身份字典补豆瓣评分，原地写入 ``vote_average`` / ``rating_ts``。

    :param pairs: ``(榜单原始标题, 身份字典)`` 序列；身份字典里读 ``title_cn`` /
                  ``year`` / ``type`` 决定检索词与年份校验
    :param budget: 本轮最多查多少条（现在一条 = 1 个请求）
    :return: 实际消耗的额度

    已经缓存过且未过期的条目直接跳过，因此稳态下（榜单条目重复率极高）
    每轮只会为「新进榜的几条」付出请求。
    """
    if budget <= 0:
        return 0
    now_ts = (now or datetime.datetime.now()).timestamp()
    used = 0
    for title, entry in pairs:
        if used >= budget or is_blocked():
            break
        if not isinstance(entry, dict) or not title:
            continue
        if is_fresh(entry, now_ts):
            continue
        keywords = []
        cn_title = str(entry.get("title_cn") or "").strip()
        if cn_title and cn_title != title:
            keywords.append(cn_title)
        keywords.append(title)
        year = str(entry.get("year") or "").strip()
        entry_type = str(entry.get("type") or "").strip().lower()
        if entry_type in ("电视剧", "tv", "show", "动漫", "anime"):
            prefer_tv: Optional[bool] = True
        elif entry_type in ("电影", "movie", "film"):
            prefer_tv = False
        else:
            prefer_tv = None
        info = lookup(title, keywords=keywords, year=year,
                      prefer_tv=prefer_tv, need_poster=False, need_rating=True)
        used += 1
        entry["rating_ts"] = now_ts
        entry["rating_ver"] = RATING_VER
        if info.get("rate"):
            entry["vote_average"] = info["rate"]
            logger.info(f"豆瓣评分补全：{title} -> {info['rate']}")
        else:
            entry["vote_average"] = ""
    return used
